These sprites were ripped by Makron including some that aren't even used in the game.
Please credit Makron used in a project.